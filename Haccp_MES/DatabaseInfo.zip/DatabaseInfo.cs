﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Haccp_MES
{
    static class DatabaseInfo
    {
        private static string dbconnectstr = "datasource=175.200.94.253;port=3306;Database=mes;username=messi;password=haccp";

        public static string DBConnectStr()
        {
            return dbconnectstr;
        }
    }
}
